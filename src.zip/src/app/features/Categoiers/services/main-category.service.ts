import { inject, Injectable } from '@angular/core';
import { ApiService } from '../../../core/services/api.service';
import { map, Observable } from 'rxjs';
import {
  propertyGroups,
  PropertyGroupsResponse,
} from '../models/main-category.model';
import { apiResponse } from '../../../core/model/apiResponse.model';

@Injectable({
  providedIn: 'root',
})
export class MainCategoryService {
  private readonly api = inject(ApiService);
  private readonly endpoint = '/api/dashboard/property-groups';
  constructor() {}

  // ==========================
  // GET ALL
  // ==========================

  getAll(
    pageIndex: number = 1,
    pageSize: number = 10,
  ): Observable<PropertyGroupsResponse> {
    const params: any = {
      pageIndex,
      pageSize,
    };

    return this.api
      .get<apiResponse<propertyGroups>>(this.endpoint, params)
      .pipe(
        map((res) => {
          return {
            categories: res.data.data,
            totalPages: res.data.totalPages,
            totalCount: res.data.count,
          };
        }),
      );
  }

  // ==========================
  // GET BY ID
  // ==========================

  getById(id: number): Observable<propertyGroups> {
    return this.api
      .get<{ data: propertyGroups }>(`${this.endpoint}/${id}`)
      .pipe(
        map((res) => res.data), // 👈 هنا ناخد الجزء اللي فعليًا فيه object الفئة
      );
  }

  // ==========================
  // CREATE
  // ==========================

  create(body: { name: string }): Observable<{ message: string }> {
    return this.api.post<{ message: string }>(this.endpoint, body);
  }

  // ==========================
  // UPDATE
  // ==========================

  update(body: { id?: number; name: string }): Observable<{ message: string }> {
    return this.api.put<{ message: string }>(`${this.endpoint}`, body);
  }

  // ==========================
  // DELETE
  // ==========================

  delete(id: number): Observable<{ message: string }> {
    return this.api.delete<{ message: string }>(`${this.endpoint}/${id}`);
  }
}
